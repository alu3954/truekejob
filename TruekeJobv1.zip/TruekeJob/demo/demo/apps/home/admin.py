from django.contrib import admin
from demo.apps.home.models import user_Profile


admin.site.register(user_Profile)
